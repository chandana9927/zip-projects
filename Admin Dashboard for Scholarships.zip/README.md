
  # Admin Dashboard for Scholarships

  This is a code bundle for Admin Dashboard for Scholarships. The original project is available at https://www.figma.com/design/3deHcrqPKvai9WRdQVdTv9/Admin-Dashboard-for-Scholarships.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  