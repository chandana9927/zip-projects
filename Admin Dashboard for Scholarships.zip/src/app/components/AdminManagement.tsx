import { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  Grid,
  Button,
  TextField,
  MenuItem,
  CircularProgress,
} from '@mui/material';
import { Visibility, CheckCircle, Cancel } from '@mui/icons-material';
import { projectId, publicAnonKey } from '/utils/supabase/info';

interface AdminRegistration {
  userId: string;
  representor: {
    firstName: string;
    middleName: string;
    lastName: string;
    email: string;
    phone: string;
    position: string;
    dateOfBirth: string;
    govtIdType: string;
    govtIdNumber: string;
    aadhaarNumber?: string;
    panNumber?: string;
  };
  company: {
    name: string;
    registrationId: string;
    taxId: string;
    businessLicenseNumber: string;
    industry: string;
    dateOfIncorporation: string;
    website: string;
    email: string;
    phone: string;
    cin?: string;
    gstin?: string;
    pan?: string;
  };
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  verification: {
    status: 'pending' | 'approved' | 'rejected';
    submittedAt: string;
    reviewedAt?: string;
    reviewedBy?: string;
    notes?: string;
  };
}

export default function AdminManagement() {
  const [admins, setAdmins] = useState<AdminRegistration[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAdmin, setSelectedAdmin] = useState<AdminRegistration | null>(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [verifyDialogOpen, setVerifyDialogOpen] = useState(false);
  const [verificationData, setVerificationData] = useState({
    status: 'approved' as 'approved' | 'rejected',
    reviewedBy: '',
    notes: '',
  });

  useEffect(() => {
    fetchAdmins();
  }, []);

  const fetchAdmins = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-7683541e/admin/all`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      const data = await response.json();
      setAdmins(data.admins || []);
    } catch (error) {
      console.error('Error fetching admins:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (admin: AdminRegistration) => {
    setSelectedAdmin(admin);
    setViewDialogOpen(true);
  };

  const handleOpenVerify = (admin: AdminRegistration) => {
    setSelectedAdmin(admin);
    setVerificationData({
      status: 'approved',
      reviewedBy: '',
      notes: '',
    });
    setVerifyDialogOpen(true);
  };

  const handleVerify = async () => {
    if (!selectedAdmin) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-7683541e/admin/${selectedAdmin.userId}/verify`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(verificationData),
        }
      );

      if (response.ok) {
        setVerifyDialogOpen(false);
        fetchAdmins();
      }
    } catch (error) {
      console.error('Error verifying admin:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'success';
      case 'rejected':
        return 'error';
      case 'pending':
        return 'warning';
      default:
        return 'default';
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Registered Admins
      </Typography>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Admin ID</TableCell>
              <TableCell>Representor Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Company</TableCell>
              <TableCell>Position</TableCell>
              <TableCell>Submitted</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {admins.map((admin) => (
              <TableRow key={admin.userId}>
                <TableCell>
                  <Typography variant="body2" fontFamily="monospace">
                    {admin.userId}
                  </Typography>
                </TableCell>
                <TableCell>
                  {admin.representor.firstName} {admin.representor.middleName}{' '}
                  {admin.representor.lastName}
                </TableCell>
                <TableCell>{admin.representor.email}</TableCell>
                <TableCell>{admin.company.name}</TableCell>
                <TableCell>{admin.representor.position}</TableCell>
                <TableCell>
                  {new Date(admin.verification.submittedAt).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  <Chip
                    label={admin.verification.status.toUpperCase()}
                    color={getStatusColor(admin.verification.status)}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <IconButton
                    size="small"
                    color="primary"
                    onClick={() => handleViewDetails(admin)}
                  >
                    <Visibility fontSize="small" />
                  </IconButton>
                  {admin.verification.status === 'pending' && (
                    <IconButton
                      size="small"
                      color="success"
                      onClick={() => handleOpenVerify(admin)}
                    >
                      <CheckCircle fontSize="small" />
                    </IconButton>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog
        open={viewDialogOpen}
        onClose={() => setViewDialogOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Admin Registration Details</DialogTitle>
        <DialogContent>
          {selectedAdmin && (
            <Box sx={{ mt: 2 }}>
              <Paper sx={{ p: 3, mb: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Representor Information
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Full Name
                    </Typography>
                    <Typography>
                      {selectedAdmin.representor.firstName}{' '}
                      {selectedAdmin.representor.middleName}{' '}
                      {selectedAdmin.representor.lastName}
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Email
                    </Typography>
                    <Typography>{selectedAdmin.representor.email}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Phone
                    </Typography>
                    <Typography>{selectedAdmin.representor.phone}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Position
                    </Typography>
                    <Typography>{selectedAdmin.representor.position}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Date of Birth
                    </Typography>
                    <Typography>{selectedAdmin.representor.dateOfBirth || 'N/A'}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Government ID
                    </Typography>
                    <Typography>
                      {selectedAdmin.representor.govtIdType}:{' '}
                      {selectedAdmin.representor.govtIdNumber}
                    </Typography>
                  </Grid>
                  {selectedAdmin.representor.aadhaarNumber && (
                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">
                        Aadhaar Number
                      </Typography>
                      <Typography>{selectedAdmin.representor.aadhaarNumber}</Typography>
                    </Grid>
                  )}
                  {selectedAdmin.representor.panNumber && (
                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">
                        PAN Number
                      </Typography>
                      <Typography>{selectedAdmin.representor.panNumber}</Typography>
                    </Grid>
                  )}
                </Grid>
              </Paper>

              <Paper sx={{ p: 3, mb: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Company Information
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Typography variant="body2" color="text.secondary">
                      Company Name
                    </Typography>
                    <Typography>{selectedAdmin.company.name}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Registration ID
                    </Typography>
                    <Typography>{selectedAdmin.company.registrationId}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Tax ID
                    </Typography>
                    <Typography>{selectedAdmin.company.taxId}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Business License
                    </Typography>
                    <Typography>
                      {selectedAdmin.company.businessLicenseNumber || 'N/A'}
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Industry
                    </Typography>
                    <Typography>{selectedAdmin.company.industry}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Company Email
                    </Typography>
                    <Typography>{selectedAdmin.company.email}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Company Phone
                    </Typography>
                    <Typography>{selectedAdmin.company.phone}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Website
                    </Typography>
                    <Typography>{selectedAdmin.company.website || 'N/A'}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Date of Incorporation
                    </Typography>
                    <Typography>
                      {selectedAdmin.company.dateOfIncorporation || 'N/A'}
                    </Typography>
                  </Grid>
                  {selectedAdmin.company.cin && (
                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">
                        CIN (Corporate Identity Number)
                      </Typography>
                      <Typography>{selectedAdmin.company.cin}</Typography>
                    </Grid>
                  )}
                  {selectedAdmin.company.gstin && (
                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">
                        GSTIN
                      </Typography>
                      <Typography>{selectedAdmin.company.gstin}</Typography>
                    </Grid>
                  )}
                  {selectedAdmin.company.pan && (
                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">
                        Company PAN
                      </Typography>
                      <Typography>{selectedAdmin.company.pan}</Typography>
                    </Grid>
                  )}
                </Grid>
              </Paper>

              <Paper sx={{ p: 3, mb: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Address
                </Typography>
                <Typography>
                  {selectedAdmin.address.street}
                  <br />
                  {selectedAdmin.address.city}, {selectedAdmin.address.state}{' '}
                  {selectedAdmin.address.zipCode}
                  <br />
                  {selectedAdmin.address.country}
                </Typography>
              </Paper>

              <Paper sx={{ p: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Verification Status
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Status
                    </Typography>
                    <Chip
                      label={selectedAdmin.verification.status.toUpperCase()}
                      color={getStatusColor(selectedAdmin.verification.status)}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Submitted At
                    </Typography>
                    <Typography>
                      {new Date(selectedAdmin.verification.submittedAt).toLocaleString()}
                    </Typography>
                  </Grid>
                  {selectedAdmin.verification.reviewedAt && (
                    <>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">
                          Reviewed At
                        </Typography>
                        <Typography>
                          {new Date(selectedAdmin.verification.reviewedAt).toLocaleString()}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">
                          Reviewed By
                        </Typography>
                        <Typography>{selectedAdmin.verification.reviewedBy}</Typography>
                      </Grid>
                      {selectedAdmin.verification.notes && (
                        <Grid item xs={12}>
                          <Typography variant="body2" color="text.secondary">
                            Notes
                          </Typography>
                          <Typography>{selectedAdmin.verification.notes}</Typography>
                        </Grid>
                      )}
                    </>
                  )}
                </Grid>
              </Paper>
            </Box>
          )}
        </DialogContent>
      </Dialog>

      <Dialog
        open={verifyDialogOpen}
        onClose={() => setVerifyDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Verify Admin Registration</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
            <TextField
              select
              label="Verification Status"
              value={verificationData.status}
              onChange={(e) =>
                setVerificationData({
                  ...verificationData,
                  status: e.target.value as 'approved' | 'rejected',
                })
              }
            >
              <MenuItem value="approved">Approve</MenuItem>
              <MenuItem value="rejected">Reject</MenuItem>
            </TextField>
            <TextField
              label="Reviewed By"
              value={verificationData.reviewedBy}
              onChange={(e) =>
                setVerificationData({ ...verificationData, reviewedBy: e.target.value })
              }
            />
            <TextField
              label="Notes (Optional)"
              multiline
              rows={3}
              value={verificationData.notes}
              onChange={(e) =>
                setVerificationData({ ...verificationData, notes: e.target.value })
              }
            />
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
              <Button onClick={() => setVerifyDialogOpen(false)}>Cancel</Button>
              <Button variant="contained" onClick={handleVerify}>
                Submit
              </Button>
            </Box>
          </Box>
        </DialogContent>
      </Dialog>
    </Box>
  );
}
