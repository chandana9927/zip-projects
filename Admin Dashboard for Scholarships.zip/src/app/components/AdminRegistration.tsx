import { useState } from 'react';
import {
  Box,
  Typography,
  TextField,
  Button,
  Paper,
  Stepper,
  Step,
  StepLabel,
  Grid,
  MenuItem,
  Alert,
  Snackbar,
} from '@mui/material';
import { PersonAdd, Business, LocationOn, VerifiedUser } from '@mui/icons-material';
import { projectId, publicAnonKey } from '/utils/supabase/info';

const steps = ['Personal Information', 'Company Details', 'Address & Contact', 'Review & Submit'];

const govtIdTypes = [
  'Aadhaar Card',
  'PAN Card',
  'Passport',
  'Voter ID',
  'Driving License',
  'Social Security Number',
  'National ID Card',
  'Tax Identification Number',
];

const industries = [
  'Technology',
  'Finance',
  'Healthcare',
  'Education',
  'Manufacturing',
  'Retail',
  'Consulting',
  'Real Estate',
  'Other',
];

export default function AdminRegistration() {
  const [activeStep, setActiveStep] = useState(0);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' as 'success' | 'error' });
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    representor: {
      firstName: '',
      middleName: '',
      lastName: '',
      email: '',
      phone: '',
      position: '',
      dateOfBirth: '',
      govtIdType: '',
      govtIdNumber: '',
      aadhaarNumber: '',
      panNumber: '',
    },
    company: {
      name: '',
      registrationId: '',
      taxId: '',
      businessLicenseNumber: '',
      industry: '',
      dateOfIncorporation: '',
      website: '',
      email: '',
      phone: '',
      cin: '',
      gstin: '',
      pan: '',
    },
    address: {
      street: '',
      city: '',
      state: '',
      zipCode: '',
      country: '',
    },
  });

  const handleNext = () => {
    if (validateCurrentStep()) {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    } else {
      setSnackbar({
        open: true,
        message: 'Please fill in all required fields',
        severity: 'error',
      });
    }
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const validateCurrentStep = () => {
    switch (activeStep) {
      case 0:
        return (
          formData.representor.firstName &&
          formData.representor.lastName &&
          formData.representor.email &&
          formData.representor.phone &&
          formData.representor.position &&
          formData.representor.govtIdType &&
          formData.representor.govtIdNumber
        );
      case 1:
        return (
          formData.company.name &&
          formData.company.registrationId &&
          formData.company.taxId &&
          formData.company.industry &&
          formData.company.email &&
          formData.company.phone
        );
      case 2:
        return (
          formData.address.street &&
          formData.address.city &&
          formData.address.state &&
          formData.address.zipCode &&
          formData.address.country
        );
      default:
        return true;
    }
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-7683541e/admin/register`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(formData),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Registration failed');
      }

      setSnackbar({
        open: true,
        message: `Registration successful! Your Admin ID: ${data.userId}`,
        severity: 'success',
      });

      setTimeout(() => {
        window.location.reload();
      }, 3000);
    } catch (error) {
      console.error('Registration error:', error);
      setSnackbar({
        open: true,
        message: error.message || 'Failed to submit registration',
        severity: 'error',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const updateField = (section: string, field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value,
      },
    }));
  };

  const renderStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <PersonAdd color="primary" />
                <Typography variant="h6">Representor Information</Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                required
                fullWidth
                label="First Name"
                value={formData.representor.firstName}
                onChange={(e) => updateField('representor', 'firstName', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Middle Name"
                value={formData.representor.middleName}
                onChange={(e) => updateField('representor', 'middleName', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                required
                fullWidth
                label="Last Name"
                value={formData.representor.lastName}
                onChange={(e) => updateField('representor', 'lastName', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Email Address"
                type="email"
                value={formData.representor.email}
                onChange={(e) => updateField('representor', 'email', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Phone Number"
                value={formData.representor.phone}
                onChange={(e) => updateField('representor', 'phone', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Position/Designation"
                value={formData.representor.position}
                onChange={(e) => updateField('representor', 'position', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Date of Birth"
                type="date"
                InputLabelProps={{ shrink: true }}
                value={formData.representor.dateOfBirth}
                onChange={(e) => updateField('representor', 'dateOfBirth', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                select
                fullWidth
                label="Government ID Type"
                value={formData.representor.govtIdType}
                onChange={(e) => updateField('representor', 'govtIdType', e.target.value)}
              >
                {govtIdTypes.map((type) => (
                  <MenuItem key={type} value={type}>
                    {type}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Government ID Number"
                value={formData.representor.govtIdNumber}
                onChange={(e) => updateField('representor', 'govtIdNumber', e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle2" color="primary" gutterBottom>
                Indian Government IDs (if applicable)
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Aadhaar Number"
                placeholder="XXXX XXXX XXXX"
                value={formData.representor.aadhaarNumber}
                onChange={(e) => updateField('representor', 'aadhaarNumber', e.target.value)}
                helperText="12-digit Aadhaar number"
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="PAN Number"
                placeholder="ABCDE1234F"
                value={formData.representor.panNumber}
                onChange={(e) => updateField('representor', 'panNumber', e.target.value.toUpperCase())}
                helperText="10-character PAN"
                inputProps={{ maxLength: 10 }}
              />
            </Grid>
          </Grid>
        );

      case 1:
        return (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <Business color="primary" />
                <Typography variant="h6">Company Information</Typography>
              </Box>
            </Grid>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="Company Name"
                value={formData.company.name}
                onChange={(e) => updateField('company', 'name', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Company Registration ID"
                value={formData.company.registrationId}
                onChange={(e) => updateField('company', 'registrationId', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Tax ID / EIN"
                value={formData.company.taxId}
                onChange={(e) => updateField('company', 'taxId', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Business License Number"
                value={formData.company.businessLicenseNumber}
                onChange={(e) => updateField('company', 'businessLicenseNumber', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                select
                fullWidth
                label="Industry"
                value={formData.company.industry}
                onChange={(e) => updateField('company', 'industry', e.target.value)}
              >
                {industries.map((industry) => (
                  <MenuItem key={industry} value={industry}>
                    {industry}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Date of Incorporation"
                type="date"
                InputLabelProps={{ shrink: true }}
                value={formData.company.dateOfIncorporation}
                onChange={(e) => updateField('company', 'dateOfIncorporation', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Company Website"
                value={formData.company.website}
                onChange={(e) => updateField('company', 'website', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Company Email"
                type="email"
                value={formData.company.email}
                onChange={(e) => updateField('company', 'email', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Company Phone"
                value={formData.company.phone}
                onChange={(e) => updateField('company', 'phone', e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle2" color="primary" gutterBottom>
                Indian Company Registration (if applicable)
              </Typography>
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="CIN"
                placeholder="U12345MH2020PTC123456"
                value={formData.company.cin}
                onChange={(e) => updateField('company', 'cin', e.target.value.toUpperCase())}
                helperText="Corporate Identity Number"
                inputProps={{ maxLength: 21 }}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="GSTIN"
                placeholder="22AAAAA0000A1Z5"
                value={formData.company.gstin}
                onChange={(e) => updateField('company', 'gstin', e.target.value.toUpperCase())}
                helperText="Goods & Services Tax ID"
                inputProps={{ maxLength: 15 }}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Company PAN"
                placeholder="ABCDE1234F"
                value={formData.company.pan}
                onChange={(e) => updateField('company', 'pan', e.target.value.toUpperCase())}
                helperText="Company PAN"
                inputProps={{ maxLength: 10 }}
              />
            </Grid>
          </Grid>
        );

      case 2:
        return (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <LocationOn color="primary" />
                <Typography variant="h6">Company Address</Typography>
              </Box>
            </Grid>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="Street Address"
                value={formData.address.street}
                onChange={(e) => updateField('address', 'street', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="City"
                value={formData.address.city}
                onChange={(e) => updateField('address', 'city', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="State / Province"
                value={formData.address.state}
                onChange={(e) => updateField('address', 'state', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="ZIP / Postal Code"
                value={formData.address.zipCode}
                onChange={(e) => updateField('address', 'zipCode', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Country"
                value={formData.address.country}
                onChange={(e) => updateField('address', 'country', e.target.value)}
              />
            </Grid>
          </Grid>
        );

      case 3:
        return (
          <Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
              <VerifiedUser color="primary" />
              <Typography variant="h6">Review Your Information</Typography>
            </Box>

            <Paper sx={{ p: 3, mb: 2 }}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                Representor Information
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    Name
                  </Typography>
                  <Typography>
                    {formData.representor.firstName} {formData.representor.middleName}{' '}
                    {formData.representor.lastName}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    Email
                  </Typography>
                  <Typography>{formData.representor.email}</Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    Position
                  </Typography>
                  <Typography>{formData.representor.position}</Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    Government ID
                  </Typography>
                  <Typography>
                    {formData.representor.govtIdType}: {formData.representor.govtIdNumber}
                  </Typography>
                </Grid>
                {formData.representor.aadhaarNumber && (
                  <Grid item xs={12} sm={6}>
                    <Typography variant="body2" color="text.secondary">
                      Aadhaar Number
                    </Typography>
                    <Typography>{formData.representor.aadhaarNumber}</Typography>
                  </Grid>
                )}
                {formData.representor.panNumber && (
                  <Grid item xs={12} sm={6}>
                    <Typography variant="body2" color="text.secondary">
                      PAN Number
                    </Typography>
                    <Typography>{formData.representor.panNumber}</Typography>
                  </Grid>
                )}
              </Grid>
            </Paper>

            <Paper sx={{ p: 3, mb: 2 }}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                Company Information
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Typography variant="body2" color="text.secondary">
                    Company Name
                  </Typography>
                  <Typography>{formData.company.name}</Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    Registration ID
                  </Typography>
                  <Typography>{formData.company.registrationId}</Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    Tax ID
                  </Typography>
                  <Typography>{formData.company.taxId}</Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    Industry
                  </Typography>
                  <Typography>{formData.company.industry}</Typography>
                </Grid>
                {formData.company.cin && (
                  <Grid item xs={12} sm={6}>
                    <Typography variant="body2" color="text.secondary">
                      CIN
                    </Typography>
                    <Typography>{formData.company.cin}</Typography>
                  </Grid>
                )}
                {formData.company.gstin && (
                  <Grid item xs={12} sm={6}>
                    <Typography variant="body2" color="text.secondary">
                      GSTIN
                    </Typography>
                    <Typography>{formData.company.gstin}</Typography>
                  </Grid>
                )}
                {formData.company.pan && (
                  <Grid item xs={12} sm={6}>
                    <Typography variant="body2" color="text.secondary">
                      Company PAN
                    </Typography>
                    <Typography>{formData.company.pan}</Typography>
                  </Grid>
                )}
              </Grid>
            </Paper>

            <Paper sx={{ p: 3 }}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                Address
              </Typography>
              <Typography>
                {formData.address.street}, {formData.address.city}, {formData.address.state}{' '}
                {formData.address.zipCode}, {formData.address.country}
              </Typography>
            </Paper>

            <Alert severity="info" sx={{ mt: 3 }}>
              Please review all information carefully. Once submitted, your registration will be
              pending approval by the system administrators.
            </Alert>
          </Box>
        );

      default:
        return null;
    }
  };

  return (
    <Box sx={{ maxWidth: 900, mx: 'auto', p: 3 }}>
      <Typography variant="h4" gutterBottom align="center">
        Admin Registration
      </Typography>
      <Typography variant="body1" color="text.secondary" align="center" sx={{ mb: 4 }}>
        Register your organization to manage scholarships and internships
      </Typography>

      <Paper sx={{ p: 4 }}>
        <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        {renderStepContent(activeStep)}

        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
          <Button disabled={activeStep === 0} onClick={handleBack}>
            Back
          </Button>
          <Box>
            {activeStep === steps.length - 1 ? (
              <Button variant="contained" onClick={handleSubmit} disabled={submitting}>
                {submitting ? 'Submitting...' : 'Submit Registration'}
              </Button>
            ) : (
              <Button variant="contained" onClick={handleNext}>
                Next
              </Button>
            )}
          </Box>
        </Box>
      </Paper>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert severity={snackbar.severity} onClose={() => setSnackbar({ ...snackbar, open: false })}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
