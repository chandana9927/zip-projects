import { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Chip,
  IconButton,
  Box,
  Typography,
} from '@mui/material';
import { Edit, Delete, Add } from '@mui/icons-material';

export interface Scholarship {
  id: number;
  name: string;
  amount: number;
  criteria: {
    minGPA: number;
    maxAge: number;
    fieldOfStudy: string[];
    nationality: string[];
  };
  deadline: string;
  status: 'Active' | 'Inactive';
}

const initialScholarships: Scholarship[] = [
  {
    id: 1,
    name: 'Merit Excellence Scholarship',
    amount: 5000,
    criteria: {
      minGPA: 3.5,
      maxAge: 25,
      fieldOfStudy: ['Computer Science', 'Engineering', 'Mathematics'],
      nationality: ['USA', 'Canada', 'UK'],
    },
    deadline: '2026-08-15',
    status: 'Active',
  },
  {
    id: 2,
    name: 'Diversity in Tech Scholarship',
    amount: 7500,
    criteria: {
      minGPA: 3.0,
      maxAge: 30,
      fieldOfStudy: ['Computer Science', 'Information Technology'],
      nationality: ['Any'],
    },
    deadline: '2026-09-30',
    status: 'Active',
  },
  {
    id: 3,
    name: 'Women in STEM Grant',
    amount: 10000,
    criteria: {
      minGPA: 3.2,
      maxAge: 28,
      fieldOfStudy: ['Engineering', 'Physics', 'Chemistry', 'Biology'],
      nationality: ['USA', 'Mexico', 'Canada'],
    },
    deadline: '2026-07-01',
    status: 'Active',
  },
];

export default function ScholarshipManagement() {
  const [scholarships, setScholarships] = useState<Scholarship[]>(initialScholarships);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingScholarship, setEditingScholarship] = useState<Scholarship | null>(null);
  const [formData, setFormData] = useState<Partial<Scholarship>>({});

  const handleOpenDialog = (scholarship?: Scholarship) => {
    if (scholarship) {
      setEditingScholarship(scholarship);
      setFormData(scholarship);
    } else {
      setEditingScholarship(null);
      setFormData({
        name: '',
        amount: 0,
        criteria: {
          minGPA: 0,
          maxAge: 0,
          fieldOfStudy: [],
          nationality: [],
        },
        deadline: '',
        status: 'Active',
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingScholarship(null);
    setFormData({});
  };

  const handleSave = () => {
    if (editingScholarship) {
      setScholarships(
        scholarships.map((s) =>
          s.id === editingScholarship.id ? { ...formData as Scholarship, id: editingScholarship.id } : s
        )
      );
    } else {
      const newScholarship = {
        ...formData as Scholarship,
        id: Math.max(...scholarships.map((s) => s.id)) + 1,
      };
      setScholarships([...scholarships, newScholarship]);
    }
    handleCloseDialog();
  };

  const handleDelete = (id: number) => {
    setScholarships(scholarships.filter((s) => s.id !== id));
  };

  return (
    <Box>
      <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h5">Scholarship Management</Typography>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => handleOpenDialog()}
        >
          Add Scholarship
        </Button>
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Amount</TableCell>
              <TableCell>Min GPA</TableCell>
              <TableCell>Max Age</TableCell>
              <TableCell>Field of Study</TableCell>
              <TableCell>Deadline</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {scholarships.map((scholarship) => (
              <TableRow key={scholarship.id}>
                <TableCell>{scholarship.name}</TableCell>
                <TableCell>${scholarship.amount.toLocaleString()}</TableCell>
                <TableCell>{scholarship.criteria.minGPA}</TableCell>
                <TableCell>{scholarship.criteria.maxAge}</TableCell>
                <TableCell>
                  <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                    {scholarship.criteria.fieldOfStudy.map((field) => (
                      <Chip key={field} label={field} size="small" />
                    ))}
                  </Box>
                </TableCell>
                <TableCell>{scholarship.deadline}</TableCell>
                <TableCell>
                  <Chip
                    label={scholarship.status}
                    color={scholarship.status === 'Active' ? 'success' : 'default'}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <IconButton
                    size="small"
                    onClick={() => handleOpenDialog(scholarship)}
                    color="primary"
                  >
                    <Edit fontSize="small" />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => handleDelete(scholarship.id)}
                    color="error"
                  >
                    <Delete fontSize="small" />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingScholarship ? 'Edit Scholarship' : 'Add New Scholarship'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
            <TextField
              label="Scholarship Name"
              fullWidth
              value={formData.name || ''}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
            <TextField
              label="Amount ($)"
              type="number"
              fullWidth
              value={formData.amount || ''}
              onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
            />
            <TextField
              label="Minimum GPA"
              type="number"
              inputProps={{ step: 0.1, min: 0, max: 4 }}
              fullWidth
              value={formData.criteria?.minGPA || ''}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  criteria: { ...formData.criteria!, minGPA: Number(e.target.value) },
                })
              }
            />
            <TextField
              label="Maximum Age"
              type="number"
              fullWidth
              value={formData.criteria?.maxAge || ''}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  criteria: { ...formData.criteria!, maxAge: Number(e.target.value) },
                })
              }
            />
            <TextField
              label="Deadline"
              type="date"
              fullWidth
              InputLabelProps={{ shrink: true }}
              value={formData.deadline || ''}
              onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button onClick={handleSave} variant="contained">
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
