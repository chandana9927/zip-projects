import { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Chip,
  IconButton,
  Box,
  Typography,
  Avatar,
} from '@mui/material';
import { Edit, Delete, Add, Business } from '@mui/icons-material';

export interface Internship {
  id: number;
  companyName: string;
  companyLogo?: string;
  position: string;
  location: string;
  duration: string;
  stipend: number;
  requirements: {
    minGPA: number;
    skills: string[];
    yearOfStudy: string[];
  };
  openings: number;
  applicationDeadline: string;
  status: 'Open' | 'Closed' | 'Filled';
}

const initialInternships: Internship[] = [
  {
    id: 1,
    companyName: 'TechCorp Solutions',
    position: 'Software Engineering Intern',
    location: 'San Francisco, CA',
    duration: '12 weeks',
    stipend: 6000,
    requirements: {
      minGPA: 3.0,
      skills: ['React', 'JavaScript', 'Node.js'],
      yearOfStudy: ['Junior', 'Senior'],
    },
    openings: 5,
    applicationDeadline: '2026-06-15',
    status: 'Open',
  },
  {
    id: 2,
    companyName: 'DataDrive Analytics',
    position: 'Data Science Intern',
    location: 'New York, NY',
    duration: '16 weeks',
    stipend: 7500,
    requirements: {
      minGPA: 3.3,
      skills: ['Python', 'Machine Learning', 'SQL', 'Statistics'],
      yearOfStudy: ['Junior', 'Senior', 'Graduate'],
    },
    openings: 3,
    applicationDeadline: '2026-06-30',
    status: 'Open',
  },
  {
    id: 3,
    companyName: 'CloudScale Systems',
    position: 'DevOps Engineering Intern',
    location: 'Austin, TX',
    duration: '10 weeks',
    stipend: 5500,
    requirements: {
      minGPA: 2.8,
      skills: ['Docker', 'Kubernetes', 'AWS', 'Linux'],
      yearOfStudy: ['Sophomore', 'Junior', 'Senior'],
    },
    openings: 2,
    applicationDeadline: '2026-07-10',
    status: 'Open',
  },
  {
    id: 4,
    companyName: 'FinTech Innovations',
    position: 'Product Management Intern',
    location: 'Boston, MA',
    duration: '12 weeks',
    stipend: 6500,
    requirements: {
      minGPA: 3.2,
      skills: ['Product Strategy', 'User Research', 'Agile'],
      yearOfStudy: ['Junior', 'Senior', 'Graduate'],
    },
    openings: 1,
    applicationDeadline: '2026-06-01',
    status: 'Filled',
  },
];

export default function InternshipManagement() {
  const [internships, setInternships] = useState<Internship[]>(initialInternships);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingInternship, setEditingInternship] = useState<Internship | null>(null);
  const [formData, setFormData] = useState<Partial<Internship>>({});

  const handleOpenDialog = (internship?: Internship) => {
    if (internship) {
      setEditingInternship(internship);
      setFormData(internship);
    } else {
      setEditingInternship(null);
      setFormData({
        companyName: '',
        position: '',
        location: '',
        duration: '',
        stipend: 0,
        requirements: {
          minGPA: 0,
          skills: [],
          yearOfStudy: [],
        },
        openings: 0,
        applicationDeadline: '',
        status: 'Open',
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingInternship(null);
    setFormData({});
  };

  const handleSave = () => {
    if (editingInternship) {
      setInternships(
        internships.map((i) =>
          i.id === editingInternship.id ? { ...formData as Internship, id: editingInternship.id } : i
        )
      );
    } else {
      const newInternship = {
        ...formData as Internship,
        id: Math.max(...internships.map((i) => i.id)) + 1,
      };
      setInternships([...internships, newInternship]);
    }
    handleCloseDialog();
  };

  const handleDelete = (id: number) => {
    setInternships(internships.filter((i) => i.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open':
        return 'success';
      case 'Closed':
        return 'error';
      case 'Filled':
        return 'warning';
      default:
        return 'default';
    }
  };

  return (
    <Box>
      <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h5">Internship Partnerships</Typography>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => handleOpenDialog()}
        >
          Add Internship
        </Button>
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Company</TableCell>
              <TableCell>Position</TableCell>
              <TableCell>Location</TableCell>
              <TableCell>Duration</TableCell>
              <TableCell>Stipend</TableCell>
              <TableCell>Min GPA</TableCell>
              <TableCell>Skills Required</TableCell>
              <TableCell>Openings</TableCell>
              <TableCell>Deadline</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {internships.map((internship) => (
              <TableRow key={internship.id}>
                <TableCell>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Avatar sx={{ width: 32, height: 32, bgcolor: 'primary.main' }}>
                      <Business fontSize="small" />
                    </Avatar>
                    {internship.companyName}
                  </Box>
                </TableCell>
                <TableCell>{internship.position}</TableCell>
                <TableCell>{internship.location}</TableCell>
                <TableCell>{internship.duration}</TableCell>
                <TableCell>${internship.stipend.toLocaleString()}/month</TableCell>
                <TableCell>{internship.requirements.minGPA}</TableCell>
                <TableCell>
                  <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', maxWidth: 200 }}>
                    {internship.requirements.skills.slice(0, 2).map((skill) => (
                      <Chip key={skill} label={skill} size="small" />
                    ))}
                    {internship.requirements.skills.length > 2 && (
                      <Chip
                        label={`+${internship.requirements.skills.length - 2}`}
                        size="small"
                        variant="outlined"
                      />
                    )}
                  </Box>
                </TableCell>
                <TableCell>{internship.openings}</TableCell>
                <TableCell>{internship.applicationDeadline}</TableCell>
                <TableCell>
                  <Chip
                    label={internship.status}
                    color={getStatusColor(internship.status)}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <IconButton
                    size="small"
                    onClick={() => handleOpenDialog(internship)}
                    color="primary"
                  >
                    <Edit fontSize="small" />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => handleDelete(internship.id)}
                    color="error"
                  >
                    <Delete fontSize="small" />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingInternship ? 'Edit Internship' : 'Add New Internship'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
            <TextField
              label="Company Name"
              fullWidth
              value={formData.companyName || ''}
              onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
            />
            <TextField
              label="Position Title"
              fullWidth
              value={formData.position || ''}
              onChange={(e) => setFormData({ ...formData, position: e.target.value })}
            />
            <TextField
              label="Location"
              fullWidth
              value={formData.location || ''}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            />
            <Box sx={{ display: 'flex', gap: 2 }}>
              <TextField
                label="Duration"
                fullWidth
                value={formData.duration || ''}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
              />
              <TextField
                label="Monthly Stipend ($)"
                type="number"
                fullWidth
                value={formData.stipend || ''}
                onChange={(e) => setFormData({ ...formData, stipend: Number(e.target.value) })}
              />
            </Box>
            <TextField
              label="Minimum GPA"
              type="number"
              inputProps={{ step: 0.1, min: 0, max: 4 }}
              fullWidth
              value={formData.requirements?.minGPA || ''}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  requirements: { ...formData.requirements!, minGPA: Number(e.target.value) },
                })
              }
            />
            <Box sx={{ display: 'flex', gap: 2 }}>
              <TextField
                label="Number of Openings"
                type="number"
                fullWidth
                value={formData.openings || ''}
                onChange={(e) => setFormData({ ...formData, openings: Number(e.target.value) })}
              />
              <TextField
                label="Application Deadline"
                type="date"
                fullWidth
                InputLabelProps={{ shrink: true }}
                value={formData.applicationDeadline || ''}
                onChange={(e) => setFormData({ ...formData, applicationDeadline: e.target.value })}
              />
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button onClick={handleSave} variant="contained">
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
