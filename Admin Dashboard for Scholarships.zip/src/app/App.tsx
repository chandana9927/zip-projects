import { useState } from 'react';
import { Tabs, Tab, Box, Container, AppBar, Toolbar, Typography } from '@mui/material';
import { School, Work, PersonAdd, ManageAccounts } from '@mui/icons-material';
import ScholarshipManagement from './components/ScholarshipManagement';
import InternshipManagement from './components/InternshipManagement';
import AdminRegistration from './components/AdminRegistration';
import AdminManagement from './components/AdminManagement';

export default function App() {
  const [activeTab, setActiveTab] = useState(0);

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  return (
    <div className="size-full">
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Admin Dashboard
          </Typography>
        </Toolbar>
      </AppBar>

      <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
          <Tabs value={activeTab} onChange={handleTabChange}>
            <Tab icon={<PersonAdd />} label="Register Admin" iconPosition="start" />
            <Tab icon={<ManageAccounts />} label="Manage Admins" iconPosition="start" />
            <Tab icon={<School />} label="Scholarships" iconPosition="start" />
            <Tab icon={<Work />} label="Internships" iconPosition="start" />
          </Tabs>
        </Box>

        <Box>
          {activeTab === 0 && <AdminRegistration />}
          {activeTab === 1 && <AdminManagement />}
          {activeTab === 2 && <ScholarshipManagement />}
          {activeTab === 3 && <InternshipManagement />}
        </Box>
      </Container>
    </div>
  );
}