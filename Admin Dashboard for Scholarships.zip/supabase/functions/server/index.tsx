import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import * as adminReg from "./admin_registration.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-7683541e/health", (c) => {
  return c.json({ status: "ok" });
});

// Admin Registration Endpoints

// Create new admin registration
app.post("/make-server-7683541e/admin/register", async (c) => {
  try {
    const body = await c.req.json();
    const result = await adminReg.createAdminRegistration(body);

    if (!result.success) {
      return c.json({ error: result.error }, 400);
    }

    return c.json({
      message: 'Registration submitted successfully',
      userId: result.userId
    }, 201);
  } catch (error) {
    console.error('Error in admin registration endpoint:', error);
    return c.json({ error: 'Failed to process registration: ' + error.message }, 500);
  }
});

// Get all admin registrations
app.get("/make-server-7683541e/admin/all", async (c) => {
  try {
    const admins = await adminReg.getAllAdmins();
    return c.json({ admins });
  } catch (error) {
    console.error('Error fetching all admins:', error);
    return c.json({ error: 'Failed to fetch admins: ' + error.message }, 500);
  }
});

// Get admin by user ID
app.get("/make-server-7683541e/admin/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const admin = await adminReg.getAdminByUserId(userId);

    if (!admin) {
      return c.json({ error: 'Admin not found' }, 404);
    }

    return c.json({ admin });
  } catch (error) {
    console.error('Error fetching admin:', error);
    return c.json({ error: 'Failed to fetch admin: ' + error.message }, 500);
  }
});

// Update verification status
app.put("/make-server-7683541e/admin/:userId/verify", async (c) => {
  try {
    const userId = c.req.param('userId');
    const { status, reviewedBy, notes } = await c.req.json();

    const result = await adminReg.updateVerificationStatus(userId, status, reviewedBy, notes);

    if (!result.success) {
      return c.json({ error: result.error }, 400);
    }

    return c.json({ message: 'Verification status updated successfully' });
  } catch (error) {
    console.error('Error updating verification status:', error);
    return c.json({ error: 'Failed to update verification: ' + error.message }, 500);
  }
});

Deno.serve(app.fetch);