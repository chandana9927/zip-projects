import * as kv from "./kv_store.tsx";

export interface AdminRegistration {
  userId: string;
  representor: {
    firstName: string;
    middleName: string;
    lastName: string;
    email: string;
    phone: string;
    position: string;
    dateOfBirth: string;
    govtIdType: string;
    govtIdNumber: string;
    aadhaarNumber?: string;
    panNumber?: string;
  };
  company: {
    name: string;
    registrationId: string;
    taxId: string;
    businessLicenseNumber: string;
    industry: string;
    dateOfIncorporation: string;
    website: string;
    email: string;
    phone: string;
    cin?: string;
    gstin?: string;
    pan?: string;
  };
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  verification: {
    status: 'pending' | 'approved' | 'rejected';
    submittedAt: string;
    reviewedAt?: string;
    reviewedBy?: string;
    notes?: string;
  };
}

export const createAdminRegistration = async (data: Omit<AdminRegistration, 'userId' | 'verification'>): Promise<{ success: boolean; userId?: string; error?: string }> => {
  try {
    // Check if email already exists
    const existingAdmins = await kv.getByPrefix('admin:user:');
    const emailExists = existingAdmins.some(
      (admin: AdminRegistration) => admin.representor.email === data.representor.email
    );

    if (emailExists) {
      return { success: false, error: 'An admin with this email already exists' };
    }

    // Generate unique user ID
    const userId = `ADM-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;

    const registration: AdminRegistration = {
      userId,
      ...data,
      verification: {
        status: 'pending',
        submittedAt: new Date().toISOString(),
      },
    };

    // Store in database with key pattern admin:user:{userId}
    await kv.set(`admin:user:${userId}`, registration);

    // Create email index for quick lookup
    await kv.set(`admin:email:${data.representor.email}`, userId);

    return { success: true, userId };
  } catch (error) {
    console.error('Error creating admin registration:', error);
    return { success: false, error: error.message || 'Failed to create registration' };
  }
};

export const getAdminByUserId = async (userId: string): Promise<AdminRegistration | null> => {
  try {
    const admin = await kv.get(`admin:user:${userId}`);
    return admin || null;
  } catch (error) {
    console.error('Error fetching admin by userId:', error);
    return null;
  }
};

export const getAdminByEmail = async (email: string): Promise<AdminRegistration | null> => {
  try {
    const userId = await kv.get(`admin:email:${email}`);
    if (!userId) return null;
    return await getAdminByUserId(userId);
  } catch (error) {
    console.error('Error fetching admin by email:', error);
    return null;
  }
};

export const getAllAdmins = async (): Promise<AdminRegistration[]> => {
  try {
    const admins = await kv.getByPrefix('admin:user:');
    return admins || [];
  } catch (error) {
    console.error('Error fetching all admins:', error);
    return [];
  }
};

export const updateVerificationStatus = async (
  userId: string,
  status: 'approved' | 'rejected',
  reviewedBy: string,
  notes?: string
): Promise<{ success: boolean; error?: string }> => {
  try {
    const admin = await getAdminByUserId(userId);
    if (!admin) {
      return { success: false, error: 'Admin not found' };
    }

    admin.verification = {
      ...admin.verification,
      status,
      reviewedAt: new Date().toISOString(),
      reviewedBy,
      notes,
    };

    await kv.set(`admin:user:${userId}`, admin);
    return { success: true };
  } catch (error) {
    console.error('Error updating verification status:', error);
    return { success: false, error: error.message || 'Failed to update status' };
  }
};
