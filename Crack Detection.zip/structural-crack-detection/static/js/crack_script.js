// Structural Crack Detection System - JavaScript

// Global variables
let isProcessing = false;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Add smooth scrolling to all anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Add loading states to buttons
    document.querySelectorAll('.btn').forEach(button => {
        button.addEventListener('click', function() {
            if (!this.classList.contains('loading')) {
                addButtonLoading(this);
            }
        });
    });

    // Initialize tooltips
    initializeTooltips();
    
    // Initialize animations
    initializeAnimations();
}

// Button loading state management
function addButtonLoading(button) {
    const originalText = button.innerHTML;
    button.classList.add('loading');
    button.disabled = true;
    
    // Add spinner
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    
    // Remove loading state after 3 seconds (fallback)
    setTimeout(() => {
        removeButtonLoading(button, originalText);
    }, 3000);
}

function removeButtonLoading(button, originalText) {
    button.classList.remove('loading');
    button.disabled = false;
    button.innerHTML = originalText;
}

// File validation utilities
function validateImageFile(file) {
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/bmp', 'image/tiff'];
    const maxSize = 16 * 1024 * 1024; // 16MB

    if (!validTypes.includes(file.type)) {
        return {
            valid: false,
            error: 'Invalid file type. Please upload PNG, JPG, JPEG, BMP, or TIFF files.'
        };
    }

    if (file.size > maxSize) {
        return {
            valid: false,
            error: 'File size must be less than 16MB.'
        };
    }

    return { valid: true };
}

// Format file size for display
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Image preview utilities
function createImagePreview(file, callback) {
    const reader = new FileReader();
    reader.onload = function(e) {
        callback(e.target.result);
    };
    reader.onerror = function() {
        console.error('Error reading file');
        callback(null);
    };
    reader.readAsDataURL(file);
}

// Progress bar animation
function animateProgressBar(element, targetWidth, duration = 1000) {
    let start = null;
    const startWidth = parseFloat(element.style.width) || 0;
    const widthDiff = targetWidth - startWidth;

    function animate(timestamp) {
        if (!start) start = timestamp;
        const progress = Math.min((timestamp - start) / duration, 1);
        const currentWidth = startWidth + (widthDiff * progress);
        
        element.style.width = currentWidth + '%';
        
        if (progress < 1) {
            requestAnimationFrame(animate);
        }
    }
    
    requestAnimationFrame(animate);
}

// Confidence meter animation
function animateConfidenceMeter(element, confidence, duration = 1000) {
    const targetWidth = confidence * 100;
    animateProgressBar(element, targetWidth, duration);
}

// Severity badge animation
function animateSeverityBadge(element, severity) {
    element.style.transform = 'scale(0.8)';
    element.style.opacity = '0';
    
    setTimeout(() => {
        element.textContent = severity;
        element.className = `severity-badge severity-${severity.toLowerCase()}`;
        element.style.transform = 'scale(1)';
        element.style.opacity = '1';
        element.style.transition = 'all 0.3s ease';
    }, 150);
}

// Results display utilities
function displayDetectionResult(hascrack, confidence) {
    const statusIcon = document.getElementById('statusIcon');
    const statusText = document.getElementById('statusText');
    const confidenceFill = document.getElementById('confidenceFill');
    const confidenceText = document.getElementById('confidenceText');

    if (hascrack) {
        statusIcon.innerHTML = '<i class="fas fa-exclamation-triangle" style="color: #e53e3e;"></i>';
        statusText.textContent = 'CRACKS DETECTED';
        statusText.className = 'status-text crack-detected';
    } else {
        statusIcon.innerHTML = '<i class="fas fa-check-circle" style="color: #38a169;"></i>';
        statusText.textContent = 'NO CRACKS DETECTED';
        statusText.className = 'status-text no-crack';
    }

    // Animate confidence meter
    const confidencePercent = Math.round(confidence * 100);
    animateConfidenceMeter(confidenceFill, confidence);
    
    // Animate confidence text
    let currentPercent = 0;
    const increment = confidencePercent / 50; // 50 steps
    const timer = setInterval(() => {
        currentPercent += increment;
        if (currentPercent >= confidencePercent) {
            currentPercent = confidencePercent;
            clearInterval(timer);
        }
        confidenceText.textContent = Math.round(currentPercent) + '%';
    }, 20);
}

function displaySeverityResult(severity, score) {
    const severityBadge = document.getElementById('severityBadge');
    const severityScore = document.getElementById('severityScore');

    animateSeverityBadge(severityBadge, severity);
    
    // Animate score
    let currentScore = 0;
    const increment = score / 50;
    const timer = setInterval(() => {
        currentScore += increment;
        if (currentScore >= score) {
            currentScore = score;
            clearInterval(timer);
        }
        severityScore.textContent = Math.round(currentScore * 10) / 10;
    }, 20);
}

function displayCrackStats(crackCount, totalArea) {
    const crackCountElement = document.getElementById('crackCount');
    const crackAreaElement = document.getElementById('crackArea');

    // Animate crack count
    let currentCount = 0;
    const countTimer = setInterval(() => {
        currentCount++;
        crackCountElement.textContent = currentCount;
        if (currentCount >= crackCount) {
            clearInterval(countTimer);
        }
    }, 100);

    // Animate area
    let currentArea = 0;
    const areaIncrement = totalArea / 30;
    const areaTimer = setInterval(() => {
        currentArea += areaIncrement;
        if (currentArea >= totalArea) {
            currentArea = totalArea;
            clearInterval(areaTimer);
        }
        crackAreaElement.textContent = Math.round(currentArea) + ' px²';
    }, 50);
}

// Notification system
function showNotification(message, type = 'info', duration = 5000) {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${getNotificationIcon(type)}"></i>
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;

    // Add to page
    document.body.appendChild(notification);

    // Position notification
    const notifications = document.querySelectorAll('.notification');
    const offset = (notifications.length - 1) * 70;
    notification.style.top = `${20 + offset}px`;

    // Auto remove
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, duration);

    return notification;
}

function getNotificationIcon(type) {
    const icons = {
        'success': 'check-circle',
        'error': 'exclamation-circle',
        'warning': 'exclamation-triangle',
        'info': 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// Error handling
function handleError(error, context = '') {
    console.error(`Error ${context}:`, error);
    
    let message = 'An unexpected error occurred.';
    if (error.message) {
        message = error.message;
    } else if (typeof error === 'string') {
        message = error;
    }

    showNotification(message, 'error');
}

// API utilities
async function uploadImageForAnalysis(file, onProgress) {
    const formData = new FormData();
    formData.append('image', file);

    try {
        const response = await fetch('/upload', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        
        if (!result.success) {
            throw new Error(result.error || 'Analysis failed');
        }

        return result;
    } catch (error) {
        throw new Error(`Upload failed: ${error.message}`);
    }
}

// Image comparison utilities
function setupImageComparison() {
    const originalImage = document.getElementById('originalImage');
    const resultImage = document.getElementById('resultImage');

    if (originalImage && resultImage) {
        // Add click to zoom functionality
        [originalImage, resultImage].forEach(img => {
            img.style.cursor = 'pointer';
            img.addEventListener('click', function() {
                openImageModal(this.src, this.alt);
            });
        });
    }
}

function openImageModal(src, alt) {
    const modal = document.createElement('div');
    modal.className = 'image-modal';
    modal.innerHTML = `
        <div class="image-modal-content">
            <button class="image-modal-close" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
            <img src="${src}" alt="${alt}">
        </div>
    `;

    document.body.appendChild(modal);

    // Close on background click
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.remove();
        }
    });

    // Close on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.parentElement) {
            modal.remove();
        }
    });
}

// Tooltips
function initializeTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
}

function showTooltip(e) {
    const text = e.target.getAttribute('data-tooltip');
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.textContent = text;
    
    document.body.appendChild(tooltip);
    
    const rect = e.target.getBoundingClientRect();
    tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
    tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
    
    e.target._tooltip = tooltip;
}

function hideTooltip(e) {
    if (e.target._tooltip) {
        e.target._tooltip.remove();
        delete e.target._tooltip;
    }
}

// Animations
function initializeAnimations() {
    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);

    // Observe elements for animation
    document.querySelectorAll('.info-card, .stat-card, .result-card, .history-item').forEach(el => {
        observer.observe(el);
    });
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

// Export functions for use in templates
window.CrackDetectionApp = {
    validateImageFile,
    formatFileSize,
    createImagePreview,
    animateProgressBar,
    animateConfidenceMeter,
    displayDetectionResult,
    displaySeverityResult,
    displayCrackStats,
    showNotification,
    handleError,
    uploadImageForAnalysis,
    setupImageComparison,
    openImageModal
};

// Add CSS for notifications and modals
const additionalStyles = `
<style>
.notification {
    position: fixed;
    right: 20px;
    top: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
    z-index: 3000;
    min-width: 300px;
    transform: translateX(100%);
    animation: slideIn 0.3s ease forwards;
}

.notification-content {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem 1.5rem;
}

.notification-success {
    border-left: 4px solid #38a169;
}

.notification-error {
    border-left: 4px solid #e53e3e;
}

.notification-warning {
    border-left: 4px solid #d69e2e;
}

.notification-info {
    border-left: 4px solid #3182ce;
}

.notification-close {
    background: none;
    border: none;
    cursor: pointer;
    color: #666;
    margin-left: auto;
}

.image-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 4000;
}

.image-modal-content {
    position: relative;
    max-width: 90vw;
    max-height: 90vh;
}

.image-modal-content img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
}

.image-modal-close {
    position: absolute;
    top: -40px;
    right: 0;
    background: rgba(255, 255, 255, 0.9);
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.tooltip {
    position: absolute;
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    font-size: 0.875rem;
    z-index: 2000;
    pointer-events: none;
}

.animate-in {
    animation: fadeInUp 0.6s ease forwards;
}

@keyframes slideIn {
    to {
        transform: translateX(0);
    }
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>
`;

document.head.insertAdjacentHTML('beforeend', additionalStyles);