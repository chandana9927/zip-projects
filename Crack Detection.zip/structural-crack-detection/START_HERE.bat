@echo off
echo.
echo ========================================
echo  Structural Crack Detection System
echo ========================================
echo.
echo Starting the AI-powered crack detection system...
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python 3.7+ and try again
    pause
    exit /b 1
)

REM Install requirements if needed
echo Installing dependencies...
pip install -r requirements_crack.txt

REM Start the application
echo.
echo Starting web application...
echo Open your browser and go to: http://localhost:5000
echo.
python crack_detection_app.py

pause