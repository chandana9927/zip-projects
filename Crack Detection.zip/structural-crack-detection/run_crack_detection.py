#!/usr/bin/env python3
"""
Startup script for the Structural Crack Detection System
"""

import os
import sys
import subprocess

def check_requirements():
    """Check if all required packages are installed"""
    required_packages = [
        'flask',
        'cv2',
        'numpy',
        'PIL'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            if package == 'cv2':
                import cv2
            elif package == 'PIL':
                from PIL import Image
            else:
                __import__(package)
            print(f"✅ {package} - OK")
        except ImportError:
            missing_packages.append(package)
            print(f"❌ {package} - Missing")
    
    return missing_packages

def install_requirements():
    """Install missing requirements"""
    print("📦 Installing required packages...")
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', 'requirements_crack.txt'])
        print("✅ All packages installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install packages: {e}")
        return False

def create_directories():
    """Create necessary directories"""
    directories = [
        'static/uploads',
        'static/results',
        'templates'
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"📁 Created directory: {directory}")

def run_tests():
    """Run system tests"""
    print("🧪 Running system tests...")
    try:
        from test_crack_system import main as run_tests
        # Don't run full test suite, just check imports
        print("✅ System components loaded successfully")
        return True
    except Exception as e:
        print(f"❌ System test failed: {e}")
        return False

def main():
    """Main startup function"""
    print("🚀 Structural Crack Detection System - Startup")
    print("=" * 60)
    
    # Check Python version
    if sys.version_info < (3, 7):
        print("❌ Python 3.7 or higher is required")
        sys.exit(1)
    
    print(f"✅ Python {sys.version.split()[0]} - OK")
    
    # Create directories
    create_directories()
    
    # Check requirements
    missing = check_requirements()
    
    if missing:
        print(f"\n⚠️  Missing packages: {', '.join(missing)}")
        install_choice = input("Install missing packages? (y/N): ").strip().lower()
        
        if install_choice == 'y':
            if not install_requirements():
                print("❌ Failed to install requirements")
                sys.exit(1)
        else:
            print("❌ Cannot start without required packages")
            sys.exit(1)
    
    # Run basic tests
    if not run_tests():
        print("⚠️  Some components may not work correctly")
    
    # Start the application
    print("\n🌐 Starting Crack Detection Web Application...")
    print("📍 Application will be available at: http://localhost:5000")
    print("\n🎯 Features:")
    print("   - AI-powered crack detection")
    print("   - Computer vision analysis")
    print("   - Severity assessment")
    print("   - Maintenance recommendations")
    print("   - Visual crack highlighting")
    print("\n🛑 Press Ctrl+C to stop the server")
    print("=" * 60)
    
    try:
        from crack_detection_app import app
        app.run(debug=True, host='0.0.0.0', port=5000)
    except KeyboardInterrupt:
        print("\n👋 Server stopped by user")
    except Exception as e:
        print(f"\n❌ Error starting application: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()