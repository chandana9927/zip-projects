#!/usr/bin/env python3
"""
Test script to verify JSON serialization fix
"""

import cv2
import numpy as np
import json
from crack_ml_model import CrackDetectionModel
from image_processor import ImageProcessor

def test_json_serialization():
    """Test that all outputs can be JSON serialized"""
    print("🧪 Testing JSON Serialization Fix...")
    
    # Initialize components
    model = CrackDetectionModel()
    processor = ImageProcessor()
    
    # Create test image with cracks
    test_image = np.ones((400, 600, 3), dtype=np.uint8) * 200
    cv2.line(test_image, (50, 50), (300, 100), (0, 0, 0), 4)
    cv2.line(test_image, (200, 150), (500, 200), (0, 0, 0), 3)
    
    try:
        # Test ML model output
        print("   Testing ML model...")
        ml_result = model.predict(test_image)
        json.dumps(ml_result)  # This should not fail
        print("   ✅ ML model output is JSON serializable")
        
        # Test image processor output
        print("   Testing image processor...")
        cv_result = processor.detect_cracks(test_image)
        json.dumps(cv_result)  # This should not fail
        print("   ✅ Image processor output is JSON serializable")
        
        # Test complete pipeline
        print("   Testing complete pipeline...")
        
        # Simulate the app's process_crack_detection logic
        def convert_numpy_types(obj):
            """Convert numpy types to native Python types"""
            if isinstance(obj, dict):
                return {key: convert_numpy_types(value) for key, value in obj.items()}
            elif isinstance(obj, list):
                return [convert_numpy_types(item) for item in obj]
            elif isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, np.ndarray):
                return obj.tolist()
            else:
                return obj
        
        # Convert and test
        converted_cv_result = convert_numpy_types(cv_result)
        json.dumps(converted_cv_result)
        print("   ✅ Converted output is JSON serializable")
        
        # Test final response format
        response = {
            'success': True,
            'has_crack': bool(ml_result['has_crack']),
            'confidence': float(ml_result['confidence']),
            'crack_count': int(len(cv_result['cracks'])),
            'severity': 'Medium',
            'severity_score': 45.5,
            'crack_details': converted_cv_result['cracks'],
            'analysis_summary': converted_cv_result['summary']
        }
        
        json_output = json.dumps(response)
        print("   ✅ Final response format is JSON serializable")
        print(f"   📊 Response size: {len(json_output)} characters")
        
        print("\n🎉 All JSON serialization tests passed!")
        return True
        
    except Exception as e:
        print(f"   ❌ JSON serialization test failed: {e}")
        return False

if __name__ == "__main__":
    test_json_serialization()