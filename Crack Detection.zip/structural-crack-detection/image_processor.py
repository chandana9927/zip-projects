import cv2
import numpy as np
from typing import Dict, List, Tuple
import math

class ImageProcessor:
    """
    Advanced image processing for crack detection
    Combines multiple computer vision techniques
    """
    
    def __init__(self):
        self.min_crack_area = 50
        self.min_crack_length = 20
        self.max_crack_width = 50
        
    def preprocess_image(self, image: np.ndarray) -> np.ndarray:
        """Preprocess image for better crack detection"""
        # Convert to grayscale
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Enhance contrast using CLAHE
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(blurred)
        
        # Apply bilateral filter to preserve edges while reducing noise
        filtered = cv2.bilateralFilter(enhanced, 9, 75, 75)
        
        return filtered
    
    def detect_cracks_morphological(self, image: np.ndarray) -> List[Dict]:
        """Detect cracks using morphological operations"""
        # Preprocess
        processed = self.preprocess_image(image)
        
        # Apply adaptive threshold
        binary = cv2.adaptiveThreshold(processed, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                     cv2.THRESH_BINARY_INV, 11, 2)
        
        # Morphological operations
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        opened = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel, iterations=1)
        
        # Connect nearby crack segments
        kernel_close = cv2.getStructuringElement(cv2.MORPH_RECT, (7, 7))
        closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, kernel_close, iterations=1)
        
        # Find contours
        contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        cracks = []
        for i, contour in enumerate(contours):
            crack_info = self.analyze_contour(contour, i)
            if crack_info and self.is_crack_like(crack_info):
                cracks.append(crack_info)
        
        return cracks
    
    def detect_cracks_edge_based(self, image: np.ndarray) -> List[Dict]:
        """Detect cracks using edge detection"""
        processed = self.preprocess_image(image)
        
        # Multi-scale edge detection
        edges1 = cv2.Canny(processed, 50, 150, apertureSize=3)
        edges2 = cv2.Canny(processed, 30, 100, apertureSize=3)
        
        # Combine edges
        edges = cv2.bitwise_or(edges1, edges2)
        
        # Morphological operations to connect edges
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        dilated = cv2.dilate(edges, kernel, iterations=1)
        
        # Find contours
        contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        cracks = []
        for i, contour in enumerate(contours):
            crack_info = self.analyze_contour(contour, i)
            if crack_info and self.is_crack_like(crack_info):
                cracks.append(crack_info)
        
        return cracks
    
    def detect_cracks_hough(self, image: np.ndarray) -> List[Dict]:
        """Detect cracks using Hough line transform"""
        processed = self.preprocess_image(image)
        edges = cv2.Canny(processed, 50, 150, apertureSize=3)
        
        # Detect lines using Hough transform
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=50,
                               minLineLength=self.min_crack_length, maxLineGap=10)
        
        cracks = []
        if lines is not None:
            for i, line in enumerate(lines):
                x1, y1, x2, y2 = line[0]
                
                # Calculate line properties
                length = math.sqrt((x2-x1)**2 + (y2-y1)**2)
                angle = math.degrees(math.atan2(y2-y1, x2-x1))
                
                crack_info = {
                    'id': int(i),
                    'type': 'line',
                    'start_point': [int(x1), int(y1)],
                    'end_point': [int(x2), int(y2)],
                    'length': float(length),
                    'angle': float(angle),
                    'width': 2.0,  # Estimated width for lines
                    'area': float(length * 2),
                    'center': [int((x1+x2)/2), int((y1+y2)/2)],
                    'bbox': [int(min(x1,x2)), int(min(y1,y2)), int(abs(x2-x1)), int(abs(y2-y1))]
                }
                
                if length > self.min_crack_length:
                    cracks.append(crack_info)
        
        return cracks
    
    def analyze_contour(self, contour: np.ndarray, contour_id: int) -> Dict:
        """Analyze contour properties"""
        area = cv2.contourArea(contour)
        perimeter = cv2.arcLength(contour, True)
        
        if area < self.min_crack_area:
            return None
        
        # Bounding rectangle
        x, y, w, h = cv2.boundingRect(contour)
        
        # Calculate properties
        aspect_ratio = max(w, h) / min(w, h) if min(w, h) > 0 else 0
        extent = area / (w * h) if w * h > 0 else 0
        solidity = area / cv2.contourArea(cv2.convexHull(contour)) if cv2.contourArea(cv2.convexHull(contour)) > 0 else 0
        
        # Fit ellipse if possible
        try:
            if len(contour) >= 5:
                ellipse = cv2.fitEllipse(contour)
                (center_x, center_y), (width, height), angle = ellipse
            else:
                center_x, center_y = x + w/2, y + h/2
                width, height = w, h
                angle = 0
        except:
            center_x, center_y = x + w/2, y + h/2
            width, height = w, h
            angle = 0
        
        return {
            'id': int(contour_id),
            'type': 'contour',
            'area': float(area),
            'perimeter': float(perimeter),
            'length': float(max(w, h)),
            'width': float(min(w, h)),
            'aspect_ratio': float(aspect_ratio),
            'extent': float(extent),
            'solidity': float(solidity),
            'center': [float(center_x), float(center_y)],
            'bbox': [int(x), int(y), int(w), int(h)],
            'angle': float(angle),
            'contour': contour.tolist()  # Convert numpy array to list
        }
    
    def is_crack_like(self, crack_info: Dict) -> bool:
        """Determine if detected feature is crack-like"""
        # Check aspect ratio (cracks are elongated)
        if crack_info['aspect_ratio'] < 2.0:
            return False
        
        # Check size constraints
        if crack_info['length'] < self.min_crack_length:
            return False
        
        if crack_info['width'] > self.max_crack_width:
            return False
        
        # Check area
        if crack_info['area'] < self.min_crack_area:
            return False
        
        return True
    
    def detect_cracks(self, image: np.ndarray) -> Dict:
        """Main crack detection function combining multiple methods"""
        # Apply different detection methods
        morphological_cracks = self.detect_cracks_morphological(image)
        edge_cracks = self.detect_cracks_edge_based(image)
        hough_cracks = self.detect_cracks_hough(image)
        
        # Combine results and remove duplicates
        all_cracks = morphological_cracks + edge_cracks + hough_cracks
        filtered_cracks = self.filter_duplicate_cracks(all_cracks)
        
        # Generate summary
        summary = self.generate_crack_summary(filtered_cracks, image.shape)
        
        return {
            'cracks': filtered_cracks,
            'summary': summary,
            'detection_methods': {
                'morphological': len(morphological_cracks),
                'edge_based': len(edge_cracks),
                'hough_lines': len(hough_cracks),
                'total_before_filtering': len(all_cracks),
                'final_count': len(filtered_cracks)
            }
        }
    
    def filter_duplicate_cracks(self, cracks: List[Dict]) -> List[Dict]:
        """Remove duplicate crack detections"""
        if not cracks:
            return []
        
        filtered = []
        for crack in cracks:
            is_duplicate = False
            for existing in filtered:
                if self.are_cracks_similar(crack, existing):
                    is_duplicate = True
                    break
            
            if not is_duplicate:
                filtered.append(crack)
        
        return filtered
    
    def are_cracks_similar(self, crack1: Dict, crack2: Dict, threshold: float = 50.0) -> bool:
        """Check if two cracks are similar (likely duplicates)"""
        # Calculate distance between centers
        center1 = crack1['center']
        center2 = crack2['center']
        distance = math.sqrt((center1[0] - center2[0])**2 + (center1[1] - center2[1])**2)
        
        return distance < threshold
    
    def generate_crack_summary(self, cracks: List[Dict], image_shape: Tuple) -> Dict:
        """Generate summary statistics for detected cracks"""
        if not cracks:
            return {
                'total_cracks': 0,
                'total_area': 0,
                'average_length': 0,
                'average_width': 0,
                'crack_density': 0
            }
        
        total_area = sum(crack['area'] for crack in cracks)
        total_length = sum(crack['length'] for crack in cracks)
        total_width = sum(crack['width'] for crack in cracks)
        
        image_area = image_shape[0] * image_shape[1]
        crack_density = (len(cracks) / image_area) * 1000000  # Cracks per million pixels
        
        return {
            'total_cracks': len(cracks),
            'total_area': float(total_area),
            'total_length': float(total_length),
            'average_length': float(total_length / len(cracks)),
            'average_width': float(total_width / len(cracks)),
            'max_length': float(max(crack['length'] for crack in cracks)),
            'max_width': float(max(crack['width'] for crack in cracks)),
            'crack_density': float(crack_density),
            'area_percentage': float((total_area / image_area) * 100)
        }
    
    def annotate_cracks(self, image: np.ndarray, cracks: List[Dict]) -> np.ndarray:
        """Annotate image with detected cracks"""
        result = image.copy()
        
        for i, crack in enumerate(cracks):
            # Choose color based on crack size
            if crack['length'] > 100:
                color = (0, 0, 255)  # Red for large cracks
            elif crack['length'] > 50:
                color = (0, 165, 255)  # Orange for medium cracks
            else:
                color = (0, 255, 0)  # Green for small cracks
            
            if crack['type'] == 'line':
                # Draw line
                start = tuple(crack['start_point'])
                end = tuple(crack['end_point'])
                cv2.line(result, start, end, color, 3)
                
                # Add label
                center = crack['center']
                label = f"C{i+1}: {crack['length']:.0f}px"
                cv2.putText(result, label, (center[0], center[1] - 10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
            
            else:
                # Draw contour
                if 'contour' in crack:
                    contour = np.array(crack['contour'], dtype=np.int32)
                    cv2.drawContours(result, [contour], -1, color, 2)
                
                # Draw bounding box
                x, y, w, h = crack['bbox']
                cv2.rectangle(result, (x, y), (x + w, y + h), color, 1)
                
                # Add label
                label = f"C{i+1}: {crack['length']:.0f}x{crack['width']:.0f}"
                cv2.putText(result, label, (x, y - 10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
        
        # Add summary text
        summary_text = f"Detected Cracks: {len(cracks)}"
        cv2.putText(result, summary_text, (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.putText(result, summary_text, (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 1)
        
        return result
    
    def create_crack_mask(self, image_shape: Tuple, cracks: List[Dict]) -> np.ndarray:
        """Create binary mask of detected cracks"""
        mask = np.zeros(image_shape[:2], dtype=np.uint8)
        
        for crack in cracks:
            if crack['type'] == 'line':
                start = tuple(crack['start_point'])
                end = tuple(crack['end_point'])
                cv2.line(mask, start, end, 255, int(crack['width']))
            else:
                if 'contour' in crack:
                    contour = np.array(crack['contour'], dtype=np.int32)
                    cv2.fillPoly(mask, [contour], 255)
        
        return mask

# Test the image processor
if __name__ == "__main__":
    processor = ImageProcessor()
    
    # Create test image with artificial cracks
    test_image = np.ones((400, 600, 3), dtype=np.uint8) * 200
    
    # Add some artificial cracks
    cv2.line(test_image, (50, 50), (200, 80), (0, 0, 0), 3)
    cv2.line(test_image, (300, 100), (500, 120), (0, 0, 0), 5)
    cv2.line(test_image, (100, 200), (150, 350), (0, 0, 0), 2)
    
    # Detect cracks
    result = processor.detect_cracks(test_image)
    
    print("🔍 Image Processing Test Results:")
    print("=" * 40)
    print(f"Total cracks detected: {result['summary']['total_cracks']}")
    print(f"Total crack area: {result['summary']['total_area']:.1f} pixels")
    print(f"Average crack length: {result['summary']['average_length']:.1f} pixels")
    print(f"Detection methods used: {result['detection_methods']}")
    
    # Create annotated image
    annotated = processor.annotate_cracks(test_image, result['cracks'])
    cv2.imwrite('test_crack_detection.jpg', annotated)
    print(f"\nAnnotated image saved as: test_crack_detection.jpg")